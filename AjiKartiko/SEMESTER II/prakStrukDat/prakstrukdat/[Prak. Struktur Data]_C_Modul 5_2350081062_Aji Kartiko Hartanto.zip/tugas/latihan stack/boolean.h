/*
    Program     : boolean.h
    Author      : 2350081062, Aji Kartiko Hartanto
    Kelas       : C
    Deskripsi   : Header file dari boolean
    Tanggal     : 15 Mei 2024
*/

#ifndef boolean_H
#define boolean_H
#define true 1
#define false 0
#define ya 1
#define tidak 0
#define boolean unsigned char

#endif 