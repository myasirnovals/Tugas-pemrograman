/**
 * Program: boolean.h
 * Author: (2350081004, Muhamad Yasir Noval)
 * Kelas: A
 * Deskripsi: Header file dari boolean
 * Tanggal: 16 Mei 2024
 */

#ifndef boolean_H
#define boolean_H
#define true 1
#define false 0
#define boolean unsigned char

#endif //boolean_H
