/**
 * Program: queue.h
 * Author: (2350081004, Muhamad Yasir Noval)
 * Kelas: A
 * Deskripsi: Header file dari prototype queue
 * Tanggal: -
 */

#ifndef ADTQCLINKEDLIST_BOOLEAN_H
#define ADTQCLINKEDLIST_BOOLEAN_H

#define true 1
#define false 0
#define ya true
#define tidak false
#define boolean unsigned char

#endif //ADTQCLINKEDLIST_BOOLEAN_H
