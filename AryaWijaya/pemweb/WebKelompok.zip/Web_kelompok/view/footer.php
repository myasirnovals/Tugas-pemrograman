<!-- footer -->
<footer class="p-3" style="background-color: #e3f2fd">
    <p class="fw-bold text-center">&copy; Copyright Arya, Yasir, dan Syivana</p>
</footer>
<!-- end footer -->

<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="../js/bootstrap.bundle.js"></script>
</body>
</html>