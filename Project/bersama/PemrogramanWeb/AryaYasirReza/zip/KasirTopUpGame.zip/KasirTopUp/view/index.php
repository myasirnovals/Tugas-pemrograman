<?php

if (session_start()) {
    include "user/user.php";
} else {
    include "user/guest.php";
}