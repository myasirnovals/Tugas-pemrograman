<footer class="text-center" style="position: static;  color: white;">
    <div class="container text-muted py-4 py-lg-5">
        <p class="mb-0" style=" color: white;">Copyright © 2024 AryaRezaYasir</p>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/bs-init.js"></script>
<script src="../../assets/js/Profile-Edit-Form-profile.js"></script>
</body>
</html>