<?php
include "../app/GetData.php";

$all_game = GetAllGame();