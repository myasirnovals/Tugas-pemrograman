<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="icon" type="image/icon" href="assets/image/logo2.png">
	
	<title>Apotek Online</title>
	<style>

	</style>
</head>
<body>
	<?php
		include "home/header.php";
	?>
	
	<?php include "product/chart.php" ?>
	
	<?php
		include "home/footer.php";
	?>
	<script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>