<div class="sticky-bottom">
    <div class="container-fluid bg-dark bg-gradient pt-2">
        <div class="row">
            <div class="col-sm-12">
                <p class="text-white text-center">&copy;Copyright 2024 | built by Ammar Yusron Abhinaya</p>
            </div>
        </div>
    </div>
</div>