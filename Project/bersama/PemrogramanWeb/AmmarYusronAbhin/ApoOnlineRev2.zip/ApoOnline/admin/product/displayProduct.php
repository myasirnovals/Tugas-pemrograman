<?php
	session_start();
	if (!isset($_SESSION["user"])) {
		header("Location: ../form/login.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.min.css">
	<link rel="icon" type="image/icon" href="../../assets/image/logo2.png">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<title>Apotek Online</title>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-2 bg-dark bg-gradient rounded-end">
				<div class="container pt-4 mb-5">
					<img src="../../assets/imageUser/admin.jpg" class="bg-light rounded w-50 d-block mx-auto" title="Admin" style="cursor: pointer;">
				</div>
				<div class="form-btn mt-3 text-center">
					<a href="../../admin/admin.php" class="btn btn-light">
						<i class="fa-solid fa-house"></i>
						<span>Home</span>
					</a>
				</div>
				<div class="form-btn mt-3 text-center">
					<a href="#" class="btn btn-light">
						<i class="fa-solid fa-chart-column"></i>
						<span>Statistic</span>
					</a>
				</div>
				<div class="form-btn mt-3 text-center">
					<a href="../../admin/product/displayProduct.php" class="btn btn-light">
						<i class="fa-solid fa-box"></i>
						<span>Product</span>
					</a>
				</div>
				<div class="form-btn mt-3 text-center">
					<a href="../../admin/karyawan/displayKaryawan.php" class="btn btn-light">
						<i class="fa-solid fa-user-tie"></i>
						<span>Workers</span>
					</a>
				</div>
				<div class="form-btn mt-3 text-center">
					<a href="../../form/logout.php" class="btn btn-light">
						<i class="fa-solid fa-arrow-right-from-bracket"></i>
						<span>Log out</span>
					</a>
				</div>
			</div>
			<div class="col-10">
				<div class="container-fluid">
					<div class="row">
						<div class="col m-3 mb-5">
							<h1 class="text-center Shadows" style="text-shadow: 2px 3px 4px;">
								Apotek Online Store All Products
							</h1>
						</div>
					</div>
					<div class='container py-5'>
					  <div class='row'>
					    <?php
					      include "../../databases/db.php";
					      
					      $sql = "SELECT * FROM produk";
					      $result = mysqli_query($connect, $sql);

					      if ($result) {
					        while ($row = mysqli_fetch_assoc($result)) {
					          $id = $row['id'];
					          $nama_produk = $row['nama_produk'];
					          $keterangan_produk = $row['keterangan_produk'];
					          $harga = number_format($row["harga"], 0, ",", ".");
					          $gambar_produk = $row['gambar_produk'];
					          $tanggal_exp = $row['tanggal_exp'];

					          echo "
					            <div class='col-4'>
					              <div class='card mb-5' style='width: 18rem;'>
					                <img src='../../assets/imageProduct/".$gambar_produk."' class='card-img-top' alt='...'>
					                <div class='card-body'>
					                  <h5 class='card-title'>".$nama_produk."</h5>
					                  <p class='card-text'>".$keterangan_produk."</p>
					                </div>
					              </div>
					            </div>
					          ";
					        }
					      }
					    ?>
					    
					  </div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript" src="../../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>