<div class="container m-5">
		<table class="table">
			<thead class="table-active">
				<td>No</td>
				<td>Nama Barang</td>
				<td>Harga Barang</td>
				<td>Setting Barang</td>
			</thead>
			<tbody>
				<tr>
					<td>1</td>
					<td>Gambar & Nama Barang</td>
					<td>Harga Barang</td>
					<td><button type="button" class="btn btn-danger">Hapus</button></td>
				</tr>
                <tr>
					<td>1</td>
					<td>Gambar & Nama Barang</td>
					<td>Harga Barang</td>
					<td><button type="button" class="btn btn-danger">Hapus</button></td>
				</tr>
                <tr>
					<td>1</td>
					<td>Gambar & Nama Barang</td>
					<td>Harga Barang</td>
					<td><button type="button" class="btn btn-danger">Hapus</button></td>
				</tr>
                <tr>
					<td>1</td>
					<td>Gambar & Nama Barang</td>
					<td>Harga Barang</td>
					<td><button type="button" class="btn btn-danger">Hapus</button></td>
				</tr>
			</tbody>
		</table>
	</div>