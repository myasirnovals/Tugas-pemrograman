<?php
  include "databases/db.php";

  if (isset($_POST['submit'])) {
    if($_SESSION['user'] == 0) {
      header("Location: form/login.php");
    } else {
      $nama_barang = $_POST['nama_barang'];
      $harga_barang = $_POST['harga_barang'];
      $gambar_barang = $_POST['gambar_barang'];
      $jumlah_barang = 1;

      $sql = "SELECT * FROM cart WHERE nama_barang='$nama_barang'";
      $result = mysqli_query($connect, $sql);

      if (mysqli_num_rows($result) > 0) {
        echo "<div class='alert alert-success'>Produk anda sudah ada di keranjang</div>";
      } else {
        $insert_sql = "INSERT INTO cart(nama_barang, harga_barang, gambar_barang, jumlah_barang) VALUES ('$nama_barang', '$harga_barang', '$gambar_barang', '$jumlah_barang')";
        $result = mysqli_query($connect, $insert_sql);
        echo "<div class='alert alert-success'>Produk sudah berhasil ditambahkan ke keranjang</div>";
      }
    }
  }
?>

<div class='container py-5 mt-4'>
  <div class='row'>
    <?php
      $sql = "SELECT * FROM produk";
      $result = mysqli_query($connect, $sql);

      if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {

          ?>
            <div class='col-4'>
              <form action='' method='post'>
                <div class='card mb-5' style='width: 18rem;'>
                  <img src='assets/imageProduct/<?php echo $row['gambar_produk']; ?>' class='card-img-top' alt='...'>
                  <div class='card-body'>
                    <h5 class='card-title'><?php echo $row['nama_produk']; ?></h5>
                    <p class='card-text'><?php echo $row['keterangan_produk']; ?></p>
                    <p class='card-text'>Rp.<?php echo number_format($row['harga'], 0, ",", "."); ?>,00</p>
                    <input type='hidden' name='nama_barang' value='<?php echo $row['nama_produk']; ?>'>
                    <input type='hidden' name='harga_barang' value='<?php echo $row['harga']; ?>'>
                    <input type='hidden' name='gambar_barang' value='<?php echo $row['gambar_produk']; ?>'>
                    <input type='submit' name='submit' class='btn btn-primary' value='Add to cart!'>
                  </div>
                </div>
              </form>
            </div>
          <?php
        }
      }
    ?>
    
  </div>
</div>