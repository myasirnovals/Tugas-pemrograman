<?php
include "databases/db.php";

if (isset($_POST['submit'])) {
	$update_jumlah = $_POST['update_jumlah'];
	$update_jumlah_id = $_POST['update_jumlah_id'];

	$sql_jumlah = "UPDATE cart SET jumlah_barang='$update_jumlah' WHERE id_barang='$update_jumlah_id'";
	$result = mysqli_query($connect, $sql_jumlah);

	if ($result) {
		header("Location: chart.php");
	}
}

if (isset($_GET['remove'])) {
	$remove_id = $_GET['remove'];
	$sql_delete = "DELETE FROM cart WHERE id_barang='$remove_id'";
	$result = mysqli_query($connect, $sql_delete);

	if ($result) {
		header("Location: chart.php");
	}
}

if (isset($_GET['delete_all'])) {
	$sql_delete_all = "DELETE FROM cart";
	$result = mysqli_query($connect, $sql_delete_all);

	if ($result) {
		header("Location: chart.php");
	}
}

?>
<div style="min-height:100vh;">
	<div class="container m-5">
		<h1 class="text-center Shadows m-5" style="text-shadow: 2px 3px 4px;">Cart</h1>
		<table class="table">
			<thead class="table-active">
				<td>No</td>
				<td>Nama</td>
				<td>Harga</td>
				<td>Gambar</td>
				<td>Jumlah Barang</td>
				<td>Total Harga</td>
				<td>Setting</td>
			</thead>
			<tbody>
				<?php
				$sql = "SELECT * FROM cart";
				$result = mysqli_query($connect, $sql);
				$total = 0;
				$i = 1;

				if ($result) {
					while ($row = mysqli_fetch_assoc($result)) {
						$sub_total = $row['harga_barang'] * $row['jumlah_barang'];

						?>
						<tr>
							<td><?php echo $i++; ?></td>
							<td><?php echo $row['nama_barang']; ?></td>
							<td>Rp.<?php echo number_format($row['harga_barang'], 0, ",", "."); ?>,00</td>
							<td><img src='assets/imageProduct/<?php echo $row['gambar_barang']; ?>' width='100px'></td>
							<td>
								<form action='' method='post'>
									<input type='hidden' name='update_jumlah_id' value='<?php echo $row['id_barang']; ?>'>
									<input type='number' name='update_jumlah' size='3' min='1'
										value='<?php echo $row['jumlah_barang']; ?>'>
									<input type="submit" name="submit" name="update_btn" class="btn btn-success" value="Update"
										style='margin-left: 10px;'>
								</form>
							</td>
							<td>Rp.<?php echo number_format($sub_total, 0, ",", "."); ?>,00</td>
							<td><a href="chart.php?remove=<?php echo $row['id_barang']; ?>" class="btn btn-danger"
									onclick="return confirm('Apakah anda yakin ingin membatalkannya?')"><i
										class="fa-solid fa-trash-can"></i> Hapus</a></td>
						</tr>
						<?php
						$total += $sub_total;
					}
				}
				?>
				<tr class="table-secondary">
					<td colspan="2"><a href="product.php" class="btn btn-warning">Lanjut Belanja</a></td>
					<td colspan="3" class="text-center">Total Keseluruhan</td>
					<td>Rp.<?php echo number_format($total, 0, ",", "."); ?>,00</td>
					<td><a href="chart.php?delete_all"
							onclick="return confirm('Apakah anda yakin ingin membatalkan semua?')"
							class="btn btn-danger"><i class="fa-solid fa-trash-can"></i> Hapus</a></td>
				</tr>
			</tbody>
		</table>
		<div class="container">
			<p>
				<span>Total belanjaan anda terbilang: </span>
				<span id="harga"></span>
				<span id="total" hidden="true"><?= $total; ?></span>
			</p>
		</div>
		<div class="col-sm-12 text-center">
			<a href="pembayaran.php" class="btn btn-success <?= ($total > 1) ? '' : 'disabled' ?>"
				style="padding-right: 50px; padding-left: 50px;">Beli Sekarang!</a>
		</div>
	</div>
</div>

<script>
	let x = document.getElementById("total").innerText;

	function terbilang(nilai) {
		nilai = Math.floor(Math.abs(nilai));


		let huruf = [
			'',
			'Satu',
			'Dua',
			'Tiga',
			'Empat',
			'Lima',
			'Enam',
			'Tujuh',
			'Delapan',
			'Sembilan',
			'Sepuluh',
			'Sebelas',
		];


		let bagi = 0;

		let penyimpanan = '';

		// rumus terbilang
		if (nilai < 12) {
			penyimpanan = ' ' + huruf[nilai];
		} else if (nilai < 20) {
			penyimpanan = terbilang(Math.floor(nilai - 10)) + ' Belas';
		} else if (nilai < 100) {
			bagi = Math.floor(nilai / 10);
			penyimpanan = terbilang(bagi) + ' Puluh' + terbilang(nilai % 10);
		} else if (nilai < 200) {
			penyimpanan = ' Seratus' + terbilang(nilai - 100);
		} else if (nilai < 1000) {
			bagi = Math.floor(nilai / 100);
			penyimpanan = terbilang(bagi) + ' Ratus' + terbilang(nilai % 100);
		} else if (nilai < 2000) {
			penyimpanan = ' Seribu' + terbilang(nilai - 1000);
		} else if (nilai < 1000000) {
			bagi = Math.floor(nilai / 1000);
			penyimpanan = terbilang(bagi) + ' Ribu' + terbilang(nilai % 1000);
		} else if (nilai < 1000000000) {
			bagi = Math.floor(nilai / 1000000);
			penyimpanan = terbilang(bagi) + ' Juta' + terbilang(nilai % 1000000);
		} else if (nilai < 1000000000000) {
			bagi = Math.floor(nilai / 1000000000);
			penyimpanan = terbilang(bagi) + ' Miliar' + terbilang(nilai % 1000000000);
		} else if (nilai < 1000000000000000) {
			bagi = Math.floor(nilai / 1000000000000);
			penyimpanan = terbilang(nilai / 1000000000000) + ' Triliun' + terbilang(nilai % 1000000000000);
		}

		return penyimpanan;
	}


	document.getElementById("harga").innerText = terbilang(x) + "Rupiah";
	document.getElementById("harga").style.fontWeight = "900";

</script>