<!-- <footer class="print-hidden" style="
    position: fixed;
    left: 0;
    bottom: 0;
    height: 50px;
    width: 100%;
    background: linear-gradient(0deg, rgba(45,45,45,1) 0%, rgba(0,0,0,1) 100%);
    color: white;
    text-align: center;
">
    <p style="padding-top: 10px;">
        &copy;Copyright 2024 | built by Ammar Yusron Abhinaya
    </p>
</footer> -->

<footer>
    <nav class="navbar navbar-dark bg-dark sticky-bottom">

                <p class="text-light mx-auto">
                    &copy;Copyright 2024 | built by Ammar Yusron Abhinaya
                </p>
    </nav>
</footer>