<?php 
	include "databases/db.php";

	$sql = "SELECT * FROM user WHERE role='2'";
	$result = mysqli_query($connect, $sql);
?>

<div class="row">
	<?php 
		if ($result) {
			while ($row=mysqli_fetch_assoc($result)) {
			
			?>
				<div class="col-sm-6">
					<div class="card mb-3" style="max-width: 540px;">
					  <div class="row g-0">
					    <div class="col-md-4">
					      <img src="assets/imageUser/<?php echo $row['foto_profile']; ?>" class="img-fluid rounded-start" alt="...">
					    </div>
					    <div class="col-md-8">
					      <div class="card-body">
					        <h5 class="card-title"><?php echo $row['nama']; ?></h5>
					        <p class="card-text">
					        	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
					        </p>
					      </div>
					    </div>
					  </div>
					</div>
				</div>
			<?php
			}
		}
	?>
</div>