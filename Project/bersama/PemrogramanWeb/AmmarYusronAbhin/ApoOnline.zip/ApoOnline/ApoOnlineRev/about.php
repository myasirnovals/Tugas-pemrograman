<?php
session_start();
?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="icon" type="image/icon" href="assets/image/logo2.png">
	<title>Apotek Online</title>
</head>

<body>
	<?php
	if (isset($_SESSION["user"])) {
		include "home/headerUser.php";
	} else {
		include "home/header.php";
	}
	?>
		<?php
	include "about/content.php";
	?>

	<?php
	include "home/footer.php";
	?>
	<script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>