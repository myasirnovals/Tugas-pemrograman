<?php
	session_start();
	include 'databases/db.php';

	if (isset($_POST['submit'])) {
		$nama_user = $_POST['nama_user'];
		$no_hp = $_POST['no_hp'];
		$email = $_POST['email'];
		$pembayaran = $_POST['pembayaran'];
		$alamat = $_POST['alamat'];

		$sql_cart2 = "SELECT * FROM cart";
		$result = mysqli_query($connect, $sql_cart2);
		$harga_keseluruhan = 0;

		if ($result) {
			while ($row = mysqli_fetch_assoc($result)) {
				$nama_produk[] = $row['nama_barang'].' ('.$row['jumlah_barang'].') ';
				$harga_produk = $row['harga_barang'] * $row['jumlah_barang'];
				$harga_keseluruhan += $harga_produk;
			}
		}

		if ($pembayaran < $harga_keseluruhan) {
			echo "<script>alert('Uang anda kurang!'); document.location.href = 'pembayaran.php';</script>";
			return false;
		}

		$produk_keseluruhan = implode(', ', $nama_produk);
		$sql_detail = "INSERT INTO orders (nama_user, no_hp, email, pembayaran, alamat, total_produk, total_harga) VALUES ('$nama_user','$no_hp','$email','$pembayaran','$alamat','$produk_keseluruhan', '$harga_keseluruhan')";
		$result_cart = mysqli_query($connect, $sql_detail) or die('query failed');
		header("Location: struk.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="icon" type="image/icon" href="assets/image/logo2.png">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<style type="text/css">
		#Background {
			background-color: lightgray;
		}
	</style>
	<title>Apotek Online</title>
</head>
<body>
	<?php
		if (isset($_SESSION["user"])) {
			include "home/headerUser.php";
		} else {
			include "home/header.php";
		}
	?>
	<div class="container-fluid">
		<div class="card m-5">
		  <div class="card-header text-center">
		    Pembayaran
		  </div>
		  <div class="card-body">
		  	<?php 
		  		$sql_cart = "SELECT * FROM cart";
		  		$result = mysqli_query($connect, $sql_cart);
		  		$total = 0;
		  		$total_keseluruhan = 0;

		  		if ($result) {
		  			while ($row = mysqli_fetch_assoc($result)) { 
		  				$total_harga = $row['harga_barang'] * $row['jumlah_barang'];
		  				$total_keseluruhan = $total += $total_harga;
		  				?>
		  				<div class="text-center" id="Background">
		  					<span><?= $row['nama_barang']; ?>(<?= $row['jumlah_barang']; ?>)</span>
		  				</div>
		  		<?php
		  			} 
		  		} else {
	  				echo "
	  				<div class='alert alert-danger'>
	  					<span>Keranjang anda kosong!</span>
	  				</div>
	  				";
	  			}
		  	?>
		  	<div class="text-center" id="Background">
			  	<span>
			  		Total keseluruhan : Rp.<?php echo number_format($total_keseluruhan,0,",","."); ?>,00
			  	</span>
		  	</div>
		  	<hr>

			<form action="" method="post">
				<div class="flex">
					<table class="table border border-white">
						<thead></thead>
						<tbody>
							<tr>
								<td>
									<div class="mb-3">
								    	<label for="input1" class="form-label">Nama Anda</label>
								    	<input type="text" name="nama_user" class="form-control" id="input1" required>
								  	</div>
								</td>
								<td>
								  	<div class="mb-3">
								    	<label for="input2" class="form-label">Nomer Handphone</label>
								    	<input type="text" name="no_hp" class="form-control" id="input2" required>
								  	</div>
								</td>
							</tr>
							<tr>
								<td>
								  	<div class="mb-3">
								    	<label for="input3" class="form-label">Email Anda</label>
								    	<input type="email" name="email" class="form-control" id="input3" required>
								  	</div>
								</td>
								<td>
								  	<div class="input-group mb-3">
								  		<div class="input-group">
								  			<label for="input4" class="form-label">Pembayaran</label>
								  		</div>
										<span class="input-group-text" id="basic-addon1">Rp.</span>
										<input type="text" name="pembayaran" class="form-control" aria-label="Username" aria-describedby="basic-addon1" id="input4" required>
									</div>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<div class="form-floating">
										<div class="input-group">
												<label for="input5" class="form-label">Alamat</label>
										  </div>
										<textarea class="form-control" name="alamat" placeholder="Leave a comment here" id="input5" required></textarea>
									</div>
								</td>
							</tr>
						</tbody>
					</table>
				  	<div class="form-btn pt-3 text-center">
					  	<input type="submit" name="submit" class="btn btn-success" value="Submit">
					  	<a href="chart.php" class="btn btn-danger">Cancel</a>
				  	</div>
				</div>
			</form>
		  </div>
		</div>
		<br><br>
	</div>
	
	<?php
		include "home/footer.php";
	?>
	<script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>