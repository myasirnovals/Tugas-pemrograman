<div style="min-height:100vh;">
    <div class="container m-5">
        <div class="row row-cols-md-3 row-cols-1">
            <div class="col">
                <div class="card">
                    <img src="portfolio/portfolio_Ammar/img/pp-portfolio.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Ammar Bagas Fathurrahman W</h5>
                        <p class="card-text">Perkenalkan saya Ammar Bagas Fathurrahman W, saya adalah salah satu pembuat
                            website ini</p>
                        <a href="portfolio/portfolio_Ammar/index.html" class="btn btn-primary" target="_blank">portofolio</a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <img src="portfolio/portfolio_Ammar/img/pp-portfolio.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Muhammad Yusron Noval</h5>
                        <p class="card-text">Perkenalkan saya Muhammad Yusron Noval, saya adalah salah satu pembuat
                            website ini</p>
                        <a href="#" class="btn btn-primary">portofolio</a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <img src="portfolio/portfolio_Ammar/img/pp-portfolio.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Muhammad Abhinaya Rakan A</h5>
                        <p class="card-text">Perkenalkan saya Muhammad Abhinaya Rakan A, saya adalah salah satu pembuat
                            website ini</p>
                        <a href="#" class="btn btn-primary">portofolio</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>