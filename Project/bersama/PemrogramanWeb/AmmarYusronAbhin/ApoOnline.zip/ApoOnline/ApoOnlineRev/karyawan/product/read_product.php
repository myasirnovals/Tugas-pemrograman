<?php
	session_start();
	if (!isset($_SESSION["user"])) {
		header("Location: ../../form/login.php");
	}
?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.min.css">
	<link rel="icon" type="image/icon" href="../../assets/image/logo2.png">
	
	<title>Welcome karyawan</title>
</head>

<body>

	<?php include "../header_product.php" ?>

	<div class="container m-5">
		<div class="row">
			<p>
				<a href="add_product.php" class="btn btn-success">Add Product</a>
				<a href="../karyawan.php" class="btn btn-secondary">Kembali</a>
			</p>
			<table class="table border">
			  <thead class="table-dark">
			    <tr>
			      <th scope="col">No.</th>
			      <th scope="col">Nama</th>
			      <th scope="col">Keterangan</th>
			      <th scope="col">Harga</th>
			      <th scope="col">Gambar</th>
			      <th scope="col">Tanggal Kedaluwarsa</th>
			      <th scope="col">Aksi</th>
			    </tr>
			  </thead>
			  <tbody>
			  	<?php
			  		include "../../databases/db.php";

			  		$sql = "SELECT * FROM produk";
			  		$result = mysqli_query($connect, $sql);
			  		$i=1;

			  		if ($result) {
			  			while ($row = mysqli_fetch_assoc($result)) {
			  				$id = $row['id'];
			  				$nama_produk = $row['nama_produk'];
			  				$keterangan_produk = $row['keterangan_produk'];
			  				$harga = number_format($row["harga"], 0, ",", ".");
			  				$gambar_produk = $row['gambar_produk'];
			  				$tanggal_exp = $row['tanggal_exp'];
			  				

			  				echo "
							    <tr>
							      <th scope='row' class='text-center'>".$i++."</th>
							      <td>".$nama_produk."</td>
							      <td>".$keterangan_produk."</td>
							      <td>Rp.".$harga."</td>
							      <td><img src='../../assets/imageProduct/".$gambar_produk."' width='100px'></td>
							      <td>".$tanggal_exp."</td>
							      <td>
							      	<a href='edit_product.php?updateid=".$id."' class='btn btn-warning'>Edit</a>
							      	<a href='delete_product.php?deleteid=".$id."' class='btn btn-danger'>Hapus</a>
							      </td>
							    </tr>
			  				";
			  			}
			  		}
			  	?>
			  </tbody>
			</table>
		</div>
	</div>

	<?php include "../../home/footer.php" ?>

	<script type="text/javascript" src="../../assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>