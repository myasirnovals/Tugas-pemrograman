<?php
	session_start();
	if (!isset($_SESSION["user"])) {
		header("Location: ../form/login.php");
	}

	include "../databases/db.php";
	$id = $_SESSION["id"];
?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
	<link rel="icon" type="image/icon" href="../assets/image/logo2.png">
	
	<title>Welcome karyawan</title>
</head>

<body>

	<?php include "headerKaryawan.php" ?>

	<div class="container mt-5">
		<div class="row">
			<div class="col align-self-start">
				<?php
					$sql = "SELECT * FROM user WHERE id = '$id'";
					$result = mysqli_query($connect, $sql);
					$row = mysqli_fetch_assoc($result);

					$nama = $row['nama'];
					$email = $row['email'];
					$password = $row['password'];
					$alamat = $row['alamat'];
					$tanggal_lahir = $row['tanggal'];
					$foto_profile = $row['foto_profile'];

					if (isset($_POST['submit'])) {
						$nama = $_POST["nama_karyawan"];
						$password = $_POST["password_karyawan"];
						$alamat = $_POST["alamat_karyawan"];
						$foto_name = $_FILES["foto_profile"]["name"];
						$foto_size = $_FILES["foto_profile"]["size"];
						$tmp_name = $_FILES["foto_profile"]["tmp_name"];
						$tanggal_lahir = $_POST["tgl_lhr_karyawan"];

						$valid_foto_extension = ["jpg","png","jpeg"];
						$foto_extension = explode(".", $foto_name);
						$foto_extension = strtolower(end($foto_extension));

						$passwordHash = password_hash($password, PASSWORD_DEFAULT);
						$errors = array();

						if (empty($nama) AND empty($password) AND empty($confirm_password) AND empty($alamat) AND empty($tanggal_lahir)) {
							array_push($errors, "Semua field tidak boleh kosong");
						}

						else if (empty($nama)) {
							array_push($errors, "Nama pekerja tidak boleh kosong");
						}

						else if (empty($password)) {
							array_push($errors, "Password pekerja tidak boleh kosong");
						}

						else if (strlen($password) < 8) {
							array_push($errors, "Password harus lebih dari 8");
						}

						else if (empty($alamat)) {
							array_push($errors, "Alamat pekerja tidak boleh kosong");
						}

						else if (!in_array($foto_extension, $valid_foto_extension)) {
									array_push($errors,"Ekstensi gambar tidak valid");
						} 

						else if($foto_size > 1000000){
							array_push($errors,"Ukuran gambar terlalu besar");
						
						}

						else if (empty($tanggal_lahir)) {
							array_push($errors, "Tanggal lahir tidak boleh kosong");
						}

						if (count($errors)>0) {
							foreach ($errors as $error) {
								echo "<div class='alert alert-danger'>$error</div>";
							}
						} else {
							$new_foto_name = uniqid();
							$new_foto_name .= ".".$foto_extension;

							move_uploaded_file($tmp_name, "../assets/imageUser/".$new_foto_name);
							$sql = "UPDATE user SET id='$id', nama='$nama', password='$passwordHash', alamat='$alamat', tanggal='$tanggal_lahir', foto_profile='$new_foto_name' WHERE id='$id'";
							$result = mysqli_query($connect, $sql);
							if ($result) {
								echo "<div class='alert alert-success'>Pekerja sudah berhasil diperbaharui</div>";
							} else {
								die(mysqli_error($connect));
							}
						}
					}
				?>
				<form action="" method="post" enctype="multipart/form-data">
					<div class="card">
						<div class="card-header text-center">
						    Profile
						</div>
						<div class="card-body">
						  	<div class="row">
						    	<div class="col-4">
						    		<img src="../assets/imageUser/<?php echo $foto_profile; ?>" class="bg-light rounded w-50 d-block mx-auto mt-4">
						    	</div>
						    	<div class="col-4">
									  <div class="mb-3">
									    <label for="exampleInput1" class="form-label">Nama</label>
									    <input type="text" name="nama_karyawan" class="form-control" id="exampleInput1" value="<?php echo $nama; ?>">
									  </div>
									  <div class="mb-3">
									    <label for="exampleInput2" class="form-label">Password</label>
									    <input type="password" name="password_karyawan" class="form-control" id="exampleInput2">
									  </div>
									  <div class="mb-3">
									    <label for="exampleInput5" class="form-label">Tanggal Lahir</label>
									    <input type="date" name="tgl_lhr_karyawan" class="form-control" id="exampleInput5" value="<?php echo $tanggal_lahir; ?>">
									  </div>
						    	</div>
						    	<div class="col-4">
						    		<div class="mb-3">
									    <label for="exampleInput3" class="form-label">Email</label>
									    <input type="email" class="form-control" id="exampleInput3" aria-describedby="emailHelp" value="<?php echo $email; ?>" readonly>
									  </div>
									  <div class="mb-3">
									    <label for="exampleInput4" class="form-label">Alamat</label>
									    <textarea type="text" name="alamat_karyawan" class="form-control" id="exampleInput4"><?php echo $alamat; ?></textarea>
									  </div>
									  <div class="mb-3">
									  	<div class="input-group">
								  			<label for="inputGroupFile02" class="form-label">Foto Profile</label>
								  		</div>
									  	<input type="file" name="foto_profile" class="form-control" id="inputGroupFile02">
									  </div>
						    	</div>
						    </div>
						    <div class="text-center m-3">
							    <input type="submit" name="submit" class="btn btn-success" value="Perbaharui">
							    <a href="karyawan.php" class="btn btn-danger">Kembali</a>
						    </div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<br>

	<?php include "../home/footer.php" ?>

	<script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>