<nav class="navbar navbar-expand-lg bg-success bg-gradient" data-bs-theme="dark">
		<div class="container-fluid">
			<a class="navbar-brand" href="karyawan.php">Mode Karyawan</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse"
				data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
				aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<form action="../../form/logout.php" method="post">
					<button type="submit" class="btn btn-danger bg-gradient" name="logout">Log Out</button>
				</form>
			</div>
		</div>
	</nav>