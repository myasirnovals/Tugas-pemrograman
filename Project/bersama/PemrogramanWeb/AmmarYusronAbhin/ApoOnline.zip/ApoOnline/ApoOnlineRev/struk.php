<?php
	session_start();
	include 'databases/db.php';

	$sql = "SELECT * FROM orders";
	$result = mysqli_query($connect, $sql);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="icon" type="image/icon" href="assets/image/logo2.png">
	<title>Apotek Online</title>
	<style type="text/css">
		@media print {
		  .print-hidden {
		    display: none;
		  }
		}
	</style>
</head>
<body>
	<?php
		if (isset($_SESSION["user"])) {
			include "home/headerUser.php";
		} else {
			include "home/header.php";
		}
	?>

	<div class="container m-5">
		<div class="row">
			<div class="col mb-5">
				<h1 class="text-center Shadows print-hidden" style="text-shadow: 2px 3px 4px;">Terimakasih Sudah berbelanja</h1>
			</div>
			<div class="card">
				<?php
					$kembalian = 0;
					if ($result) {
						while ($row=mysqli_fetch_assoc($result)) { 
							$dibayar = $row['pembayaran'] - $row['total_harga'];
							$kembalian += $dibayar;
							?>
							<div class="card-body">
								<div class="container">
									<div class="row">
										<div class="col-6">
											<img src="assets/image/Logo.png" class="card-img-top w-50">
										</div>
										<div class="col-6">
											<div class="container">
												<div class="row">
													<div class="col-7 text-end">
														<b>Penjual :</b>
													</div>
													<div class="col-5">
														Apotek Online
													</div>
													<div class="col-7 text-end">
														<b>Pembeli :</b>
													</div>
													<div class="col-5">
														<?php echo $row['nama_user']; ?>
													</div>
												</div>
											</div>
										</div>
									</div>
						  		</div>
								<table class="table border">
									<tr class="text-start">
										<th>Total Produk</th>
										<th>Alamat</th>
										<th>Total Harga Produk</th>
									</tr>
									<tr>
										<td><?php echo $row['total_produk']; ?></td>
										<td><?php echo $row['alamat']; ?></td>
										<td>Rp.<?php echo number_format($row['total_harga'],0,",","."); ?>,00</td>
									</tr>
									<tr class="table-secondary">
										<td colspan="2"><b>Pembayaran</b></td>
										<td>Rp.<?php echo number_format($row['pembayaran'],0,",","."); ?>,00</td>
									</tr>
									<tr class="table-secondary">
										<td colspan="2"><b>Kembalian</b></td>
										<td>Rp.<?php echo number_format($kembalian,0,",","."); ?>,00</td>
									</tr>
								</table>
								<br>
								<div class="container">
									<p>
										<span>Kembalian belanjaan anda terbilang: </span>
										<span id="harga"></span>
										<span id="total" hidden="true"><?= $kembalian; ?></span>
									</p>
								</div>
								<hr>
								<div class="text-end">
								    <button class="btn btn-secondary print-hidden" onclick="window.print()">Cetak Struk</button>
								    <a href="index.php" class="btn btn-danger print-hidden">Kembali</a>
								</div>
						  	</div>
						<?php
						}
					}
				?>
			</div>
		</div>
	</div>
	<br><br>

	<script>
	    let x = document.getElementById("total").innerText;

	    function terbilang(nilai) {
	        nilai = Math.floor(Math.abs(nilai));


	        let huruf = [
	            '',
	            'Satu',
	            'Dua',
	            'Tiga',
	            'Empat',
	            'Lima',
	            'Enam',
	            'Tujuh',
	            'Delapan',
	            'Sembilan',
	            'Sepuluh',
	            'Sebelas',
	        ];


	        let bagi = 0;

	        let penyimpanan = '';

	        // rumus terbilang
	        if (nilai < 12) {
	            penyimpanan = ' ' + huruf[nilai];
	        } else if (nilai < 20) {
	            penyimpanan = terbilang(Math.floor(nilai - 10)) + ' Belas';
	        } else if (nilai < 100) {
	            bagi = Math.floor(nilai / 10);
	            penyimpanan = terbilang(bagi) + ' Puluh' + terbilang(nilai % 10);
	        } else if (nilai < 200) {
	            penyimpanan = ' Seratus' + terbilang(nilai - 100);
	        } else if (nilai < 1000) {
	            bagi = Math.floor(nilai / 100);
	            penyimpanan = terbilang(bagi) + ' Ratus' + terbilang(nilai % 100);
	        } else if (nilai < 2000) {
	            penyimpanan = ' Seribu' + terbilang(nilai - 1000);
	        } else if (nilai < 1000000) {
	            bagi = Math.floor(nilai / 1000);
	            penyimpanan = terbilang(bagi) + ' Ribu' + terbilang(nilai % 1000);
	        } else if (nilai < 1000000000) {
	            bagi = Math.floor(nilai / 1000000);
	            penyimpanan = terbilang(bagi) + ' Juta' + terbilang(nilai % 1000000);
	        } else if (nilai < 1000000000000) {
	            bagi = Math.floor(nilai / 1000000000);
	            penyimpanan = terbilang(bagi) + ' Miliar' + terbilang(nilai % 1000000000);
	        } else if (nilai < 1000000000000000) {
	            bagi = Math.floor(nilai / 1000000000000);
	            penyimpanan = terbilang(nilai / 1000000000000) + ' Triliun' + terbilang(nilai % 1000000000000);
	        }

	        return penyimpanan;
	    }

	    if (x == "0") {
	    	document.getElementById("harga").innerText="Nol"+" Rupiah";
		    document.getElementById("harga").style.fontWeight = "900";
	    } else {
		    document.getElementById("harga").innerText=terbilang(x)+" Rupiah";
		    document.getElementById("harga").style.fontWeight = "900";
	    }

	</script>
	
	<?php
		include "home/footer.php";
	?>
	<script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>