<?php
	session_start();
	if (!isset($_SESSION["user"])) {
		header("Location: ../form/login.php");
	}

	include '../databases/db.php';
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
	<link rel="icon" type="image/icon" href="../assets/image/logo2.png">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<style type="text/css">
		/* The sidebar menu */
		.sidenav {
		  height: 100%; /* Full-height: remove this if you want "auto" height */
		  width: 200px; /* Set the width of the sidebar */
		  position: fixed; /* Fixed Sidebar (stay in place on scroll) */
		  z-index: 1; /* Stay on top */
		  top: 0; /* Stay at the top */
		  left: 0;
		  background-color: #111; /* Black */
		  overflow-x: hidden; /* Disable horizontal scroll */
		  padding-top: 20px;
		}

		/* The navigation menu links */
		.sidenav a {
		  padding: 6px 8px 6px 16px;
		  text-decoration: none;
		  font-size: 14px;
		  color: #818181;
		  display: block;
		}

		/* When you mouse over the navigation links, change their color */
		.sidenav a:hover {
		  color: #f1f1f1;
		}

		/* Style page content */
		.main {
		  margin-left: 200px; /* Same as the width of the sidebar */
		  padding: 0px 10px;
		}

		/* On smaller screens, where height is less than 450px, change the style of the sidebar (less padding and a smaller font size) */
		@media screen and (max-height: 450px) {
		  .sidenav {padding-top: 15px;}
		  .sidenav a {font-size: 18px;}
		} 
	</style>
	<title>Apotek Online</title>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-2">
				<div class="sidenav">
					<div class="container pt-4 mb-5">
						<img src="../assets/imageUser/admin.jpg" class="bg-light rounded w-50 d-block mx-auto" title="Admin" style="cursor: pointer;">
					</div>
					<div class="form-btn mt-3 d-flex justify-content-center">
						<a href="../admin/admin.php" class="btn btn-light w-50">
							<i class="fa-solid fa-house"></i>
							<span>Home</span>
						</a>
					</div>
					<div class="form-btn mt-3 d-flex justify-content-center">
						<a href="../admin/product/displayProduct.php" class="btn btn-light w-50">
							<i class="fa-solid fa-box"></i>
							<span>Product</span>
						</a>
					</div>
					<div class="form-btn mt-3 d-flex justify-content-center">
						<a href="../admin/karyawan/displayKaryawan.php" class="btn btn-light w-50">
							<i class="fa-solid fa-user-tie"></i>
							<span>Workers</span>
						</a>
					</div>
					<div class="form-btn mt-3 d-flex justify-content-center">
						<a href="../form/logout.php" class="btn btn-light w-50">
							<i class="fa-solid fa-arrow-right-from-bracket"></i>
							<span>Log out</span>
						</a>
					</div>
				</div>
			</div>
			<div class="col-12">
				<div class="main">
					<div class="container-fluid">
						<div class="row">
							<div class="col m-3 mb-5">
								<h1 class="text-center Shadows" style="text-shadow: 2px 3px 4px;">
									Apotek Online Store
								</h1>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<div class="card mb-3" style="max-width: 540px;">
								  <div class="row g-0">
								    <div class="col-md-4">
								      <img src="../assets/imageItem/money.png" class="img-fluid rounded-start" alt="...">
								    </div>
								    <div class="col-md-8" style="padding-left: 25px;">
								    	<?php
								    		$sql_order = "SELECT * FROM orders";
								    		$result_order = mysqli_query($connect, $sql_order);
								    		$row = mysqli_fetch_assoc($result_order);
								    	?>
										<div class="card-body">
											<h5 class="card-title">Jumlah Uang</h5>
											<p class="card-text">Rp.<?php echo number_format($row['total_harga'],0,",","."); ?>,00</p>
										</div>
								    </div>
								  </div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="card mb-3" style="max-width: 540px;">
								  <div class="row g-0">
								    <div class="col-md-4">
								      <img src="../assets/imageItem/box.png" class="img-fluid rounded-start" alt="...">
								    </div>
								    <div class="col-md-8">
								    	<?php 
								    		$sql_produk = "SELECT COUNT(id) AS jumlahProduk FROM produk";
								    		$result_produk = mysqli_query($connect, $sql_produk);
								    		$row = mysqli_fetch_assoc($result_produk);
								    	?>
										<div class="card-body" style="padding-left: 25px;">
											<h5 class="card-title">Jumlah Produk</h5>
											<p class="card-text"><?php echo $row['jumlahProduk']; ?></p>
										</div>
								    </div>
								  </div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="card mb-3" style="max-width: 540px;">
								  <div class="row g-0">
								    <div class="col-md-4">
								      <img src="../assets/imageItem/chart.png" class="img-fluid rounded-start" alt="...">
								    </div>
								    <div class="col-md-8">
								    	<?php 
								    		$sql_keranjang = "SELECT COUNT(id_barang) AS jumlahKeranjang FROM cart";
								    		$result_keranjang = mysqli_query($connect, $sql_keranjang);
								    		$row = mysqli_fetch_assoc($result_keranjang);
								    	?>
										<div class="card-body" style="padding-left: 25px;">
											<h5 class="card-title">Jumlah Pesanan</h5>
											<p class="card-text"><?php echo $row['jumlahKeranjang']; ?></p>
										</div>
								    </div>
								  </div>
								</div>
							</div>
						</div>
					</div>
					<div class="container mb-5">
						<div class="mt-3 mb-3">
							<div class="form-btn d-flex justify-content-between">
								<span style="text-shadow: 2px 3px 4px; font-size: 27px;">
									Product
								</span>
								<a href="../admin/product/addProduct.php" class="btn btn-secondary">
									<span>Tambah produk</span>
									<i class="fa-solid fa-plus"></i>
								</a>
							</div>
						</div>
						<table class="table border">
						  <thead class="table-dark">
						    <tr>
						      <th scope="col">No.</th>
						      <th scope="col">Nama</th>
						      <th scope="col">Keterangan</th>
						      <th scope="col">Harga</th>
						      <th scope="col">Gambar</th>
						      <th scope="col">Tanggal Kedaluwarsa</th>
						      <th scope="col">Aksi</th>
						    </tr>
						  </thead>
						  <tbody>
						  	<?php
						  		include "../databases/db.php";

						  		$sql = "SELECT * FROM produk";
						  		$result = mysqli_query($connect, $sql);
						  		$i=1;

						  		if ($result) {
						  			while ($row = mysqli_fetch_assoc($result)) {
						  				$id = $row['id'];
						  				$nama_produk = $row['nama_produk'];
						  				$keterangan_produk = $row['keterangan_produk'];
						  				$harga = number_format($row["harga"], 0, ",", ".");
						  				$gambar_produk = $row['gambar_produk'];
						  				$tanggal_exp = $row['tanggal_exp'];
						  				

						  				echo "
										    <tr>
										      <th scope='row' class='text-center'>".$i++."</th>
										      <td>".$nama_produk."</td>
										      <td>".$keterangan_produk."</td>
										      <td>Rp.".$harga."</td>
										      <td><img src='../assets/imageProduct/".$gambar_produk."' width='100px'></td>
										      <td>".$tanggal_exp."</td>
										      <td>
										      	<a href='../admin/product/editProduct.php?updateid=".$id."' class='btn btn-warning'>Edit</a>
										      	<a href='../admin/product/deleteProduct.php?deleteid=".$id."' class='btn btn-danger'>Hapus</a>
										      </td>
										    </tr>
						  				";
						  			}
						  		}
						  	?>
						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>


	<script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>