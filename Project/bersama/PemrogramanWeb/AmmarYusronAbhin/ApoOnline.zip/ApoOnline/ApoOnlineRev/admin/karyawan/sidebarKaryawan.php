<div class="container pt-4 mb-5">
		<img src="../../assets/imageUser/admin.jpg" class="bg-light rounded w-50 d-block mx-auto" title="Admin" style="cursor: pointer;">
	</div>
	<div class="form-btn mt-3 d-flex justify-content-center">
		<a href="../../admin/admin.php" class="btn btn-light w-50">
			<i class="fa-solid fa-house"></i>
			<span>Home</span>
		</a>
	</div>
	<div class="form-btn mt-3 d-flex justify-content-center">
		<a href="../../admin/product/displayProduct.php" class="btn btn-light w-50">
			<i class="fa-solid fa-box"></i>
			<span>Product</span>
		</a>
	</div>
	<div class="form-btn mt-3 d-flex justify-content-center">
		<a href="../../admin/karyawan/displayKaryawan.php" class="btn btn-light w-50">
			<i class="fa-solid fa-user-tie"></i>
			<span>Workers</span>
		</a>
	</div>
	<div class="form-btn mt-3 d-flex justify-content-center">
		<a href="../../form/logout.php" class="btn btn-light w-50">
			<i class="fa-solid fa-arrow-right-from-bracket"></i>
			<span>Log out</span>
		</a>
	</div>
</div>