<?php
	session_start();
	if (!isset($_SESSION["user"])) {
		header("Location: ../form/login.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.min.css">
	<link rel="icon" type="image/icon" href="../../assets/image/logo2.png">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<style type="text/css">
		/* The sidebar menu */
		.sidenav {
		  height: 100%; /* Full-height: remove this if you want "auto" height */
		  width: 200px; /* Set the width of the sidebar */
		  position: fixed; /* Fixed Sidebar (stay in place on scroll) */
		  z-index: 1; /* Stay on top */
		  top: 0; /* Stay at the top */
		  left: 0;
		  background-color: #111; /* Black */
		  overflow-x: hidden; /* Disable horizontal scroll */
		  padding-top: 20px;
		}

		/* The navigation menu links */
		.sidenav a {
		  padding: 6px 8px 6px 16px;
		  text-decoration: none;
		  font-size: 14px;
		  color: #818181;
		  display: block;
		}

		/* When you mouse over the navigation links, change their color */
		.sidenav a:hover {
		  color: #f1f1f1;
		}

		/* Style page content */
		.main {
		  margin-left: 200px; /* Same as the width of the sidebar */
		  padding: 0px 10px;
		}

		/* On smaller screens, where height is less than 450px, change the style of the sidebar (less padding and a smaller font size) */
		@media screen and (max-height: 450px) {
		  .sidenav {padding-top: 15px;}
		  .sidenav a {font-size: 18px;}
		} 
	</style>
	<title>Apotek Online</title>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-2">
				<div class="sidenav">
					<?php include "sidebarKaryawan.php"; ?>
				</div>
			</div>
			<div class="col-12">
				<div class="main">
					<div class="container-fluid">
						<div class="row">
							<div class="col m-3 mb-5">
								<h1 class="text-center Shadows" style="text-shadow: 2px 3px 4px;">
									Apotek Online Workers
								</h1>
							</div>
						</div>
						<div class="container mb-5">
							<?php
								include "../../databases/db.php";

								if (isset($_POST['submit'])) {
									$nama = $_POST["nama"];
									$email = $_POST["email"];
									$password = $_POST["password"];
									$confirm_password = $_POST['confirm_password'];
									$alamat = $_POST["alamat"];
									$foto_name = $_FILES["foto_profile"]["name"];
									$foto_size = $_FILES["foto_profile"]["size"];
									$tmp_name = $_FILES["foto_profile"]["tmp_name"];
									$tanggal_lahir = $_POST["tanggal_lahir"];
									$role_worker = $_POST["role_worker"];

									$valid_foto_extension = ["jpg","png","jpeg"];
									$foto_extension = explode(".", $foto_name);
									$foto_extension = strtolower(end($foto_extension));

									$passwordHash = password_hash($password, PASSWORD_DEFAULT);
									$errors = array();

									if (empty($nama) AND empty($email) AND empty($password) AND empty($confirm_password) AND empty($alamat) AND empty($tanggal_lahir) AND empty($foto_extension) AND empty($role_worker)) {
										array_push($errors, "Semua field tidak boleh kosong");
									}

									else if (empty($nama)) {
										array_push($errors, "Nama pekerja tidak boleh kosong");
									}

									else if (empty($email)) {
										array_push($errors, "Email pekerja tidak boleh kosong");
									}

									else if (empty($password)) {
										array_push($errors, "Password pekerja tidak boleh kosong");
									}

									else if (!filter_var($email, FILTER_VALIDATE_EMAIL) AND !empty($email)) {
										array_push($errors, "Email pekerja tidak valid");
									}

									else if (strlen($password) < 8) {
										array_push($errors, "Password harus lebih dari 8");
									}

									else if ($password !== $confirm_password) {
										array_push($errors, "Password tidak sama");
									}

									else if (empty($alamat)) {
										array_push($errors, "Alamat pekerja tidak boleh kosong");
									}

									else if (empty($tanggal_lahir)) {
										array_push($errors, "Tanggal lahir tidak boleh kosong");
									}

									else if (!in_array($foto_extension, $valid_foto_extension)) {
										array_push($errors,"Ekstensi gambar tidak valid");
									} 

									else if($foto_size > 1000000){
										array_push($errors,"Ukuran gambar terlalu besar");
									
									}

									else if (empty($role_worker)) {
										array_push($errors, "Role pekerja tidak boleh kosong");
									}

									else if ($role_worker !== "2") {
										array_push($errors, "Role pekerja harus menggunakan angka 2");
									}

									$sql = "SELECT * FROM user WHERE email = '$email'";
									$result = mysqli_query($connect, $sql);
									$rowCount = mysqli_num_rows($result);

									if ($rowCount>0) {
										array_push($errors, "Email pekerja sudah ada");
									}

									if (count($errors)>0) {
										foreach ($errors as $error) {
											echo "<div class='alert alert-danger'>$error</div>";
										}
									} else {
										$new_foto_name = uniqid();
										$new_foto_name .= ".".$foto_extension;

										move_uploaded_file($tmp_name, "../../assets/imageUser/".$new_foto_name);
										$sql = "INSERT INTO user (nama, email, password, alamat, tanggal, foto_profile, role) VALUES ('$nama', '$email', '$passwordHash', '$alamat', '$tanggal_lahir', '$new_foto_name', '$role_worker')";
										$result = mysqli_query($connect, $sql);
										if ($result) {
											echo "<div class='alert alert-success'>Pekerja sudah berhasil ditambahkan</div>";
										} else {
											die(mysqli_error($connect));
										}
									}
								}
							?>
							<div class="card">
							  <div class="card-header text-center">
							    Add Workers
							  </div>
							  <div class="card-body">
								<form action="addKaryawan.php" method="post" enctype="multipart/form-data">
									<div class="mb-3">
								    	<label for="exampleInputName" class="form-label">Nama Pekerja</label>
								    	<input type="text" name="nama" class="form-control" id="exampleInputName">
								  	</div>
								  	<div class="mb-3">
								    	<label for="exampleInputEmail1" class="form-label">Email Pekerja</label>
								    	<input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
								  	</div>
								  	<div class="mb-3">
								    	<label for="exampleInputPassword" class="form-label">Password</label>
								    	<input type="password" name="password" class="form-control" id="exampleInputPassword" aria-describedby="emailHelp">
								  	</div>
								  	<div class="mb-3">
								    	<label for="exampleInputConPass" class="form-label">Confirm Password</label>
								    	<input type="password" name="confirm_password" class="form-control" id="exampleInputConPass" aria-describedby="emailHelp">
								  	</div>
								  	<div class="mb-3">
								    	<label for="exampleInputAlamat" class="form-label">Alamat</label>
								    	<input type="text" name="alamat" class="form-control" id="exampleInputAlamat">
								  	</div>
									<div class="mb-3">
								    	<label for="exampleInputDate1" class="form-label">Tanggal Lahir</label>
								    	<input type="date" name="tanggal_lahir" class="form-control" id="exampleInputDate1">
								  	</div>
								  	<div class="mb-3">
								    	<label for="exampleInputRole" class="form-label">Role</label>
								    	<input type="number" name="role_worker" class="form-control" id="exampleInputRole">
								  	</div>
								  	<div class="input-group mb-3">
								  		<div class="input-group">
								  			<label for="inputGroupFile02" class="form-label">Foto Profile</label>
								  		</div>
									  	<input type="file" name="foto_profile" class="form-control" id="inputGroupFile02">
									  	<label class="input-group-text" for="inputGroupFile02">Upload</label>
									</div>
								  	<div class="form-btn pt-3">
									  	<input type="submit" name="submit" class="btn btn-success" value="Submit">
									  	<a href="../../admin/karyawan/displayKaryawan.php" class="btn btn-danger">Cancel</a>
								  	</div>
								</form>
							  </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<script type="text/javascript" src="../../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>