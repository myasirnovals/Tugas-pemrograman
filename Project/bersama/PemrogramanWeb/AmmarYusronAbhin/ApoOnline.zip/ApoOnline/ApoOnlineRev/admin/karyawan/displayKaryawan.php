<?php
	session_start();
	if (!isset($_SESSION["user"])) {
		header("Location: ../form/login.php");
	}

	include "../../databases/db.php";
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.min.css">
	<link rel="icon" type="image/icon" href="../../assets/image/logo2.png">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<style type="text/css">
		/* The sidebar menu */
		.sidenav {
		  height: 100%; /* Full-height: remove this if you want "auto" height */
		  width: 200px; /* Set the width of the sidebar */
		  position: fixed; /* Fixed Sidebar (stay in place on scroll) */
		  z-index: 1; /* Stay on top */
		  top: 0; /* Stay at the top */
		  left: 0;
		  background-color: #111; /* Black */
		  overflow-x: hidden; /* Disable horizontal scroll */
		  padding-top: 20px;
		}

		/* The navigation menu links */
		.sidenav a {
		  padding: 6px 8px 6px 16px;
		  text-decoration: none;
		  font-size: 14px;
		  color: #818181;
		  display: block;
		}

		/* When you mouse over the navigation links, change their color */
		.sidenav a:hover {
		  color: #f1f1f1;
		}

		/* Style page content */
		.main {
		  margin-left: 200px; /* Same as the width of the sidebar */
		  padding: 0px 10px;
		}

		/* On smaller screens, where height is less than 450px, change the style of the sidebar (less padding and a smaller font size) */
		@media screen and (max-height: 450px) {
		  .sidenav {padding-top: 15px;}
		  .sidenav a {font-size: 18px;}
		} 
	</style>
	<title>Apotek Online</title>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-2">
				<div class="sidenav">
					<?php include "sidebarKaryawan.php"; ?>
				</div>
			</div>
			<div class="col-12">
				<div class="main">
					<div class="container-fluid">
						<div class="row">
							<div class="col m-3 mb-5">
								<h1 class="text-center Shadows" style="text-shadow: 2px 3px 4px;">
									Apotek Online Store Workers
								</h1>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<div class="card mb-3" style="max-width: 540px;">
								  <div class="row g-0">
								    <div class="col-md-4">
								      <img src="../../assets/imageUser/worker.png" class="img-fluid rounded-start m-4" alt="...">
								    </div>
								    <div class="col-md-8">
								    	<?php 
								    		$sql_karyawan = "SELECT COUNT(id) AS jumlahKaryawan FROM user WHERE role='2'";
								    		$result_karyawan = mysqli_query($connect, $sql_karyawan);
								    		$row = mysqli_fetch_assoc($result_karyawan);
								    	?>
										<div class="card-body" style="padding-left: 50px;">
											<h5 class="card-title">Jumlah Karyawan</h5>
											<p class="card-text"><?php echo $row['jumlahKaryawan']; ?></p>
										</div>
								    </div>
								  </div>
								</div>
							</div>
						</div>
					</div>
					<div class="container mb-5">
						<div class="mt-3 mb-3">
							<div class="form-btn d-flex justify-content-between">
								<span style="text-shadow: 2px 3px 4px; font-size: 27px;">
									Karyawan
								</span>
								<a href="../../admin/karyawan/addKaryawan.php" class="btn btn-secondary">
									<span>Tambah karyawan</span>
									<i class="fa-solid fa-plus"></i>
								</a>
							</div>
						</div>
						<table class="table border">
						  <thead class="table-dark">
						    <tr>
						      <th scope="col">No.</th>
						      <th scope="col">Nama</th>
						      <th scope="col">Alamat</th>
						      <th scope="col">Tanggal Lahir</th>
						      <th scope="col">Foto Profil</th>
						      <th scope="col">Aksi</th>
						    </tr>
						  </thead>
						  <tbody>
						  	<?php
						  		include "../../databases/db.php";

						  		$sql = "SELECT * FROM user WHERE role = '2'";
						  		$result = mysqli_query($connect, $sql);
						  		$i=1;

						  		if ($result) {
						  			while ($row = mysqli_fetch_assoc($result)) {
						  				$id = $row['id'];
						  				$nama = $row['nama'];
						  				$alamat = $row['alamat'];
						  				$tanggal_lahir = $row['tanggal'];
						  				$foto_profile = $row['foto_profile'];
						  				
						  				echo "
										    <tr>
										      <th scope='row' class='text-center'>".$i++."</th>
										      <td>".$nama."</td>
										      <td>".$alamat."</td>
										      <td>".$tanggal_lahir."</td>
										      <td><img src='../../assets/imageUser/".$foto_profile."' width='100px'></td>
										      <td>
										      	<a href='../../admin/karyawan/editKaryawan.php?updateid=".$id."' class='btn btn-warning'>Edit</a>
										      	<a href='../../admin/karyawan/deleteKaryawan.php?deleteid=".$id."' class='btn btn-danger'>Hapus</a>
										      </td>
										    </tr>
						  				";
						  			}
						  		}
						  	?>
						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript" src="../../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>